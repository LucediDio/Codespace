/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.multithread;

/**
 *
 * @author halim
 */
class RingBuffer {

    class Block {
        public static final int DIM = 64;
        private byte[] block;

        public Block(byte[] data, int n) {
            put(data, n);
        }

        public void put(byte[] data, int n) {
            block = java.util.Arrays.copyOf(data, n);
        }

        public byte[] get() {
            return java.util.Arrays.copyOf(block, block.length);
        }
    }

    public static final int N = 16;
    private Block[] ring_buffer;
    private int write_index;
    private int read_index;
    private volatile int N_block;
    private volatile boolean eof;

    public RingBuffer() {
        ring_buffer = new Block[N];
        write_index = 0;
        read_index = 0;
        N_block = 0;
        eof = false;
    }

    public synchronized void setEOF() {
        eof = true;
        notify();
    }

    public synchronized boolean end() {
        return eof && (N_block == 0);
    }

    public synchronized void put(byte[] data, int n) throws InterruptedException {
        Block block = new Block(data, n);

        while (N_block == N) {
            wait();
        }

        ring_buffer[write_index] = block;
        write_index = (write_index + 1) % N;
        N_block++;
        notify();
    }

    public synchronized byte[] get() throws InterruptedException {
        while (N_block == 0 && !eof) {
            wait();
        }

        if (N_block == 0 && eof) {
            return null;
        }

        Block block = ring_buffer[read_index];
        read_index = (read_index + 1) % N;
        N_block--;
        notify();
        return block.get();
    }
}