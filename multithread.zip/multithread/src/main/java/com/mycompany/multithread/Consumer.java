/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.multithread;

/**
 *
 * @author halim
 */
class Consumer implements Runnable {

    private RingBuffer ringBuffer;

    public Consumer(RingBuffer ringBuffer) {
        this.ringBuffer = ringBuffer;
    }

    @Override
    public void run() {
        try {
            while (true) {
                byte[] data = ringBuffer.get();
                if (data == null) {
                    break;
                }
                String value = new String(data);
                System.out.println("Consumatore riceve: " + value);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}