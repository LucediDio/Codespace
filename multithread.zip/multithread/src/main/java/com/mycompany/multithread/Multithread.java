/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multithread;
import java.util.Random;

/**
/**
 *
 * @author halim
 */
public class Multithread {

 public static void main(String[] args) throws InterruptedException {
        if (args.length != 1) {
            System.out.println("Usage: java Main <N>");
            System.exit(1);
        }

        // N = Numero di numeri casuali da generare
        int N = Integer.parseInt(args[0]);

        // Creazione del buffer condiviso
        RingBuffer ringBuffer = new RingBuffer();

        // Thread produttore
        Thread producer = new Thread(new Producer(ringBuffer, N));

        // Thread consumatore
        Thread consumer = new Thread(new Consumer(ringBuffer));

        // Avvio dei thread
        producer.start();
        consumer.start();

        // Aspetta che i thread terminino
        producer.join();
        ringBuffer.setEOF();  // Segnala la fine al consumatore
        consumer.join();
    }
}