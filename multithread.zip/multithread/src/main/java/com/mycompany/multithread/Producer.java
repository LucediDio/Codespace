/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.multithread;
import java.util.Random;
/**
 *
 * @author halim
 */
class Producer implements Runnable {

    private RingBuffer ringBuffer;
    private int N;

    public Producer(RingBuffer ringBuffer, int N) {
        this.ringBuffer = ringBuffer;
        this.N = N;
    }

    @Override
    public void run() {
        Random random = new Random();
        try {
            for (int i = 0; i < N; i++) {
                int randomNumber = random.nextInt(100); // Genera un numero casuale
                byte[] data = String.valueOf(randomNumber).getBytes();
                System.out.println("Produttore genera: " + randomNumber);
                ringBuffer.put(data, data.length);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
